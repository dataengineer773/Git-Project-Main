#!/bin/bash

rm -r /var/www/html/*